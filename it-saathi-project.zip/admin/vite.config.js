import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  base: '/admin/',
  server: {
    hmr: false,
    ws: false,
  },
  build: {
    outDir: 'dist',
  },
});
